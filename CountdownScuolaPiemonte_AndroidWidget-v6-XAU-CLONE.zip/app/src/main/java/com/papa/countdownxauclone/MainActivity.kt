package com.papa.countdownxauclone

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.days).text = CountdownUtils.daysLeft().toString()
        findViewById<TextView>(R.id.subtitle).text = "giorni alla fine della scuola in Piemonte"
        findViewById<TextView>(R.id.date).text = "Fine lezioni: ${CountdownUtils.endDateText()}"
    }
}

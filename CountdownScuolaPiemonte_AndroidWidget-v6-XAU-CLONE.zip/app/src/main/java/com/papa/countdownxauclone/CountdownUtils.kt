package com.papa.countdownxauclone

import java.time.LocalDate
import java.time.temporal.ChronoUnit

object CountdownUtils {
    private val endDate = LocalDate.of(2027, 6, 10)

    fun daysLeft(): Long {
        val today = LocalDate.now()
        return maxOf(0, ChronoUnit.DAYS.between(today, endDate))
    }

    fun endDateText(): String = "10 giugno 2027"
}

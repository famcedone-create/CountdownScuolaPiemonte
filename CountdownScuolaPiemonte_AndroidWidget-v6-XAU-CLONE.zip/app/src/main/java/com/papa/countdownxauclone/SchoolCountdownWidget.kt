package com.papa.countdownxauclone

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews

class SchoolCountdownWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val rv = RemoteViews(context.packageName, R.layout.widget_countdown)
            rv.setTextViewText(R.id.widget_days, CountdownUtils.daysLeft().toString())
            rv.setTextViewText(R.id.widget_label, "giorni alla fine della scuola")
            rv.setTextViewText(R.id.widget_date, CountdownUtils.endDateText())
            manager.updateAppWidget(id, rv)
        }
    }
}

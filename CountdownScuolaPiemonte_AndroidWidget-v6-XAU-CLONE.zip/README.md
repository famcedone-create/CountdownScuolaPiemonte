Countdown Scuola Piemonte - clone tecnico dello scheletro XAU SENT.
Build: Java 21, Kotlin 2.0.21, AGP 8.7.3, Gradle 8.10.2, AndroidX/WorkManager e jsoup come XAU SENT.

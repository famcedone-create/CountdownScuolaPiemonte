# Nessuna regola speciale necessaria.

plugins {
    id("com.android.application")
}

android {
    namespace = "com.papa.countdownscuola"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.papa.countdownscuola.clean"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

package com.papa.countdownscuola;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class SchoolCountdownWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId);
        }
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int appWidgetId) {
        CountdownUtils.Remaining r = CountdownUtils.remaining();
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_countdown);

        if (r.finished()) {
            views.setTextViewText(R.id.widgetDays, "🎉");
            views.setTextViewText(R.id.widgetSubtitle, "SCUOLA FINITA!");
        } else {
            views.setTextViewText(R.id.widgetDays, String.valueOf(r.days()));
            views.setTextViewText(R.id.widgetSubtitle, "giorni alla fine della scuola");
        }

        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widgetRoot, pendingIntent);

        manager.updateAppWidget(appWidgetId, views);
    }
}

package com.papa.countdownscuola;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;
import android.widget.RemoteViews;

public class SchoolCountdownWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, manager, appWidgetId);
        }
    }

    static void updateWidget(Context context, AppWidgetManager manager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_countdown);

        Intent openApp = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        views.setOnClickPendingIntent(R.id.widgetRoot, pendingIntent);

        if (CountdownUtils.finished()) {
            views.setTextViewText(R.id.widgetDays, "0");
            views.setTextViewText(R.id.widgetLabel, "SCUOLA FINITA! 🎉");
            views.setTextViewText(R.id.widgetChronometer, "00:00:00");
            views.setBoolean(R.id.widgetChronometer, "setStarted", false);
        } else {
            long calendarDays = CountdownUtils.calendarDaysRemaining();
            views.setTextViewText(R.id.widgetDays, String.valueOf(calendarDays));
            views.setTextViewText(R.id.widgetLabel,
                    calendarDays == 1 ? "GIORNO ALLA FINE" : "GIORNI ALLA FINE");

            long boundaryMillis = CountdownUtils.millisUntilNextBoundary();
            long base = SystemClock.elapsedRealtime() + boundaryMillis;

            views.setChronometer(R.id.widgetChronometer, base, "%s", true);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                views.setChronometerCountDown(R.id.widgetChronometer, true);
            }
        }

        manager.updateAppWidget(appWidgetId, views);
    }
}

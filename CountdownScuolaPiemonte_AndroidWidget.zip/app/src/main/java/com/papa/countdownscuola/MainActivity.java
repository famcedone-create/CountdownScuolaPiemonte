package com.papa.countdownscuola;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;

public class MainActivity extends Activity {

    private final Handler handler = new Handler(Looper.getMainLooper());

    private TextView days;
    private TextView hours;
    private TextView minutes;
    private TextView seconds;
    private TextView message;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            updateCountdown();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        days = findViewById(R.id.daysValue);
        hours = findViewById(R.id.hoursValue);
        minutes = findViewById(R.id.minutesValue);
        seconds = findViewById(R.id.secondsValue);
        message = findViewById(R.id.messageText);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ticker.run();
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    private void updateCountdown() {
        if (CountdownUtils.finished()) {
            days.setText("0");
            hours.setText("00");
            minutes.setText("00");
            seconds.setText("00");
            message.setText("SCUOLA FINITA! 🎉");
            return;
        }

        long[] r = CountdownUtils.remaining();
        days.setText(String.valueOf(r[0]));
        hours.setText(String.format("%02d", r[1]));
        minutes.setText(String.format("%02d", r[2]));
        seconds.setText(String.format("%02d", r[3]));
        message.setText("Verso il 10 giugno 2027");
    }
}

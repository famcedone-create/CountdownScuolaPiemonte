package com.papa.countdownscuola;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView days;
    private TextView hours;
    private TextView minutes;
    private TextView seconds;
    private TextView message;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateCountdown();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        days = findViewById(R.id.daysValue);
        hours = findViewById(R.id.hoursValue);
        minutes = findViewById(R.id.minutesValue);
        seconds = findViewById(R.id.secondsValue);
        message = findViewById(R.id.messageText);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(tick);
    }

    private void updateCountdown() {
        CountdownUtils.Remaining r = CountdownUtils.remaining();
        days.setText(String.valueOf(r.days()));
        hours.setText(String.format("%02d", r.hours()));
        minutes.setText(String.format("%02d", r.minutes()));
        seconds.setText(String.format("%02d", r.seconds()));
        message.setText(r.finished()
                ? "SCUOLA FINITA! 🎉"
                : "Le lezioni in Piemonte terminano il 10 giugno 2027");
    }
}

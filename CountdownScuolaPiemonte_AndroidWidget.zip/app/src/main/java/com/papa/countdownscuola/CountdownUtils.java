package com.papa.countdownscuola;

import java.time.Duration;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.ZoneId;

public final class CountdownUtils {
    public static final ZoneId ZONE = ZoneId.of("Europe/Rome");
    public static final LocalDate TARGET_DATE = LocalDate.of(2027, 6, 10);

    private CountdownUtils() {}

    public static ZonedDateTime target() {
        return TARGET_DATE.atStartOfDay(ZONE);
    }

    public static long[] remaining() {
        ZonedDateTime now = ZonedDateTime.now(ZONE);
        ZonedDateTime target = target();

        long totalSeconds = Math.max(0, Duration.between(now, target).getSeconds());

        long days = totalSeconds / 86400;
        long hours = (totalSeconds % 86400) / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        long seconds = totalSeconds % 60;

        return new long[] { days, hours, minutes, seconds };
    }

    public static long calendarDaysRemaining() {
        LocalDate today = ZonedDateTime.now(ZONE).toLocalDate();
        long d = java.time.temporal.ChronoUnit.DAYS.between(today, TARGET_DATE);
        return Math.max(0, d);
    }

    public static boolean finished() {
        return !ZonedDateTime.now(ZONE).isBefore(target());
    }

    public static long millisUntilNextBoundary() {
        ZonedDateTime now = ZonedDateTime.now(ZONE);
        ZonedDateTime target = target();

        if (!now.isBefore(target)) return 0;

        ZonedDateTime nextMidnight = now.toLocalDate().plusDays(1).atStartOfDay(ZONE);
        ZonedDateTime boundary = nextMidnight.isBefore(target) ? nextMidnight : target;
        return Math.max(0, Duration.between(now, boundary).toMillis());
    }
}

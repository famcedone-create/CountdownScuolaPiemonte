package com.papa.countdownscuola;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public final class CountdownUtils {
    private CountdownUtils() {}

    public static final ZoneId ZONE = ZoneId.of("Europe/Rome");
    public static final ZonedDateTime SCHOOL_END = ZonedDateTime.of(
            LocalDateTime.of(2027, 6, 10, 23, 59, 59), ZONE);

    public static Remaining remaining() {
        ZonedDateTime now = ZonedDateTime.now(ZONE);
        if (!now.isBefore(SCHOOL_END)) {
            return new Remaining(0, 0, 0, 0, true);
        }
        long seconds = Duration.between(now, SCHOOL_END).getSeconds();
        long days = seconds / 86400;
        seconds %= 86400;
        long hours = seconds / 3600;
        seconds %= 3600;
        long minutes = seconds / 60;
        long secs = seconds % 60;
        return new Remaining(days, hours, minutes, secs, false);
    }

    public static final class Remaining {
        private final long days;
        private final long hours;
        private final long minutes;
        private final long seconds;
        private final boolean finished;

        public Remaining(long days, long hours, long minutes, long seconds, boolean finished) {
            this.days = days;
            this.hours = hours;
            this.minutes = minutes;
            this.seconds = seconds;
            this.finished = finished;
        }

        public long days() { return days; }
        public long hours() { return hours; }
        public long minutes() { return minutes; }
        public long seconds() { return seconds; }
        public boolean finished() { return finished; }
    }
}

# Countdown Scuola Piemonte

Progetto Android pulito, ricostruito da zero con la stessa configurazione di base usata dal progetto XAU SENT che si installa correttamente sul telefono.

- Android Gradle Plugin 8.7.3
- Java 21
- compileSdk / targetSdk 35
- minSdk 26
- applicationId: com.papa.countdownscuola.clean
- fine lezioni Piemonte: 10 giugno 2027

L'app mostra un countdown e include un vero widget Android per la schermata Home.

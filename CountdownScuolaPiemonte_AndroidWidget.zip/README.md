# Countdown Scuola Piemonte 2026–2027

Widget Android nativo per il conto alla rovescia fino al **10 giugno 2027**.

## Cosa fa
- Widget 4×2 sulla schermata Home.
- Numero grande dei giorni mancanti.
- Timer visibile nel widget tramite `Chronometer`.
- Tap sul widget → apre la mini-app con giorni, ore, minuti e secondi.
- Fuso orario: Europe/Rome.
- Nessun server e nessuna connessione Internet necessari.

## Costruire l'APK con GitHub (anche dal telefono)

1. Crea un nuovo repository GitHub.
2. Estrai questo ZIP e carica **tutti** i file e le cartelle nel repository.
3. Apri la scheda **Actions**.
4. Seleziona **Build Android APK**.
5. Premi **Run workflow**.
6. Quando la build è finita, apri il job e scarica l'artifact:
   `CountdownScuolaPiemonte-debug`.
7. Estrai `app-debug.apk` dal file scaricato e installalo sul telefono.
8. Se Android lo chiede, abilita “Installa app sconosciute” per il browser/file manager usato.

## Aggiungere il widget

1. Pressione lunga su uno spazio vuoto della schermata Home.
2. Tocca **Widget**.
3. Cerca **Countdown Scuola**.
4. Trascina il widget nella Home.

## Nota sul timer

Android non consente a un normale AppWidget di eseguire codice ogni secondo in background.
Per questo il progetto usa il `Chronometer` di sistema per far scorrere il timer senza svegliare continuamente l'app, mentre il numero dei giorni viene riallineato dagli aggiornamenti del widget.
